package com.example.myapp
import androidx.compose.runtime.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import androidx.compose.ui.layout.*
import com.skydoves.landscapist.*
import com.skydoves.landscapist.coil3.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.geometry.Offset
@Composable
fun WhisprFlowCanvas() {
	Column(
		modifier = Modifier
			.fillMaxWidth()
			.fillMaxHeight()
			.background(
				color = Color(0xFFFFFFFF),
			)
	){
		Column(
			modifier = Modifier
				.fillMaxWidth()
				.weight(1f)
				.background(
					color = Color(0xFF1A1A1E),
				)
				.padding(48.dp)
		){
			Row(
				verticalAlignment = Alignment.CenterVertically,
				modifier = Modifier
					.fillMaxWidth()
			){
				Box(
					modifier = Modifier
						.padding(end = 32.dp,)
						.weight(1f)
				){
					Column(
					){
						Column(
							modifier = Modifier
								.clip(shape = RoundedCornerShape(32.dp))
								.fillMaxWidth()
								.background(
									color = Color(0xFF0C0C0E),
									shape = RoundedCornerShape(32.dp)
								)
						){
							Column(
								modifier = Modifier
									.padding(bottom = 150.dp,)
									.fillMaxWidth()
							){
								Row(
									horizontalArrangement = Arrangement.SpaceBetween,
									verticalAlignment = Alignment.CenterVertically,
									modifier = Modifier
										.fillMaxWidth()
										.padding(vertical = 15.dp,horizontal = 24.dp,)
								){
									Row(
										verticalAlignment = Alignment.CenterVertically,
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.padding(end = 8.dp,)
												.width(18.dp)
												.height(18.dp)
										)
										Text("Whispr",
											color = Color(0xFFFFFFFF),
											fontSize = 18.sp,
											fontWeight = FontWeight.Bold,
										)
									}
									Row(
										verticalAlignment = Alignment.CenterVertically,
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.padding(end = 8.dp,)
												.width(16.dp)
												.height(16.dp)
										)
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.padding(end = 8.dp,)
												.width(16.dp)
												.height(16.dp)
										)
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.width(24.dp)
												.height(16.dp)
										)
									}
								}
								Column(
									horizontalAlignment = Alignment.CenterHorizontally,
									modifier = Modifier
										.fillMaxWidth()
										.padding(vertical = 24.dp,)
								){
									Column(
										modifier = Modifier
											.padding(bottom = 44.dp,)
											.clip(shape = RoundedCornerShape(130.dp))
											.background(
												color = Color(0x08FF3B30),
												shape = RoundedCornerShape(130.dp)
											)
											.clickable { println("Pressed!") }
											.padding(25.dp)
									){
										Column(
											modifier = Modifier
												.clip(shape = RoundedCornerShape(105.dp))
												.background(
													color = Color(0x1FFF3B30),
													shape = RoundedCornerShape(105.dp)
												)
												.padding(25.dp)
										){
											Column(
												horizontalAlignment = Alignment.CenterHorizontally,
												modifier = Modifier
													.clip(shape = RoundedCornerShape(80.dp))
													.background(
														color = Color(0xFFFF3B30),
														shape = RoundedCornerShape(80.dp)
													)
													.shadow(
														elevation = 24.dp,
														spotColor = Color(0xFFFF3B30),
													)
													.padding(vertical = 51.dp,horizontal = 34.dp,)
											){
												Text("SOS",
													color = Color(0xFFFFFFFF),
													fontSize = 36.sp,
													fontWeight = FontWeight.Bold,
												)
												Text("Tap to trigger",
													color = Color(0xFFFFFFFF),
													fontSize = 11.sp,
													fontWeight = FontWeight.Bold,
												)
											}
										}
									}
									Row(
										verticalAlignment = Alignment.CenterVertically,
										modifier = Modifier
											.padding(bottom = 44.dp,start = 24.dp,end = 24.dp,)
											.border(
												width = 1.dp,
												color = Color(0xFF222226),
												shape = RoundedCornerShape(16.dp)
											)
											.clip(shape = RoundedCornerShape(16.dp))
											.fillMaxWidth()
											.background(
												color = Color(0xFF16161A),
												shape = RoundedCornerShape(16.dp)
											)
											.padding(16.dp)
									){
										Column(
											modifier = Modifier
												.padding(end = 12.dp,)
												.clip(shape = RoundedCornerShape(6.dp))
												.width(12.dp)
												.height(12.dp)
												.background(
													color = Color(0xFFFF3B30),
													shape = RoundedCornerShape(6.dp)
												)
										){
										}
										Column(
											modifier = Modifier
												.weight(1f)
										){
											Text("SOS Active State: Armed",
												color = Color(0xFFFFFFFF),
												fontSize = 14.sp,
												fontWeight = FontWeight.Bold,
												modifier = Modifier
													.padding(bottom = 2.dp,)
											)
											Text("5 Active ICE contacts will be pinged instantly",
												color = Color(0xFF8E8E93),
												fontSize = 12.sp,
											)
										}
									}
									Column(
										modifier = Modifier
											.padding(horizontal = 24.dp,)
											.fillMaxWidth()
									){
										Row(
											horizontalArrangement = Arrangement.SpaceBetween,
											verticalAlignment = Alignment.CenterVertically,
											modifier = Modifier
												.padding(bottom = 16.dp,)
												.fillMaxWidth()
										){
											Text("ICE Contacts",
												color = Color(0xFFFFFFFF),
												fontSize = 16.sp,
												fontWeight = FontWeight.Bold,
											)
											Text("View All",
												color = Color(0xFFFF3B30),
												fontSize = 12.sp,
												fontWeight = FontWeight.Bold,
											)
										}
										Row(
											verticalAlignment = Alignment.CenterVertically,
											modifier = Modifier
												.fillMaxWidth()
										){
											Column(
												horizontalAlignment = Alignment.CenterHorizontally,
												modifier = Modifier
													.padding(end = 12.dp,)
													.padding(horizontal = 3.dp,)
											){
												CoilImage(
													imageModel = {"https://i.imgur.com/1tMFzp8.png"},
													imageOptions = ImageOptions(contentScale = ContentScale.Crop),
													modifier = Modifier
														.padding(bottom = 6.dp,)
														.clip(shape = RoundedCornerShape(28.dp))
														.width(56.dp)
														.height(56.dp)
												)
												Text("Sarah Miller",
													color = Color(0xFFFFFFFF),
													fontSize = 12.sp,
													modifier = Modifier
														.padding(bottom = 6.dp,)
												)
												Text("Mom",
													color = Color(0xFF8E8E93),
													fontSize = 10.sp,
												)
											}
											Column(
												horizontalAlignment = Alignment.CenterHorizontally,
												modifier = Modifier
													.padding(end = 12.dp,)
													.padding(horizontal = 3.dp,)
											){
												CoilImage(
													imageModel = {"https://i.imgur.com/1tMFzp8.png"},
													imageOptions = ImageOptions(contentScale = ContentScale.Crop),
													modifier = Modifier
														.padding(bottom = 6.dp,)
														.clip(shape = RoundedCornerShape(28.dp))
														.width(56.dp)
														.height(56.dp)
												)
												Text("Marcus Chen",
													color = Color(0xFFFFFFFF),
													fontSize = 12.sp,
													modifier = Modifier
														.padding(bottom = 6.dp,)
												)
												Text("Partner",
													color = Color(0xFF8E8E93),
													fontSize = 10.sp,
												)
											}
											Column(
												horizontalAlignment = Alignment.CenterHorizontally,
												modifier = Modifier
													.padding(end = 12.dp,)
													.padding(horizontal = 8.dp,)
											){
												CoilImage(
													imageModel = {"https://i.imgur.com/1tMFzp8.png"},
													imageOptions = ImageOptions(contentScale = ContentScale.Crop),
													modifier = Modifier
														.padding(bottom = 6.dp,)
														.clip(shape = RoundedCornerShape(28.dp))
														.width(56.dp)
														.height(56.dp)
												)
												Text("Dr. Evans",
													color = Color(0xFFFFFFFF),
													fontSize = 12.sp,
													modifier = Modifier
														.padding(bottom = 6.dp,)
												)
												Text("Doctor",
													color = Color(0xFF8E8E93),
													fontSize = 10.sp,
												)
											}
											Column(
												horizontalAlignment = Alignment.CenterHorizontally,
												modifier = Modifier
													.padding(horizontal = 1.dp,)
											){
												CoilImage(
													imageModel = {"https://i.imgur.com/1tMFzp8.png"},
													imageOptions = ImageOptions(contentScale = ContentScale.Crop),
													modifier = Modifier
														.padding(bottom = 6.dp,)
														.clip(shape = RoundedCornerShape(28.dp))
														.width(56.dp)
														.height(56.dp)
												)
												Text("Officer Reed",
													color = Color(0xFFFFFFFF),
													fontSize = 12.sp,
													modifier = Modifier
														.padding(bottom = 6.dp,)
												)
												Text("Friend",
													color = Color(0xFF8E8E93),
													fontSize = 10.sp,
												)
											}
										}
									}
								}
							}
							Row(
								horizontalArrangement = Arrangement.SpaceBetween,
								verticalAlignment = Alignment.CenterVertically,
								modifier = Modifier
									.fillMaxWidth()
									.background(
										color = Color(0xFF0C0C0E),
									)
									.drawBehind {
										val borderTopWidth = 1.dp.toPx()
										drawLine(
											color = Color(0xFF222226),
											start = Offset(0f, borderTopWidth / 2),
											end = Offset(size.width, borderTopWidth / 2),
											strokeWidth = borderTopWidth
										)              
										}
									.padding(vertical = 10.dp,horizontal = 16.dp,)
							){
								Column(
									horizontalAlignment = Alignment.CenterHorizontally,
									modifier = Modifier
										.width(80.dp)
								){
									Column(
										horizontalAlignment = Alignment.CenterHorizontally,
										modifier = Modifier
											.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
											.clip(shape = RoundedCornerShape(16.dp))
											.fillMaxWidth()
											.background(
												color = Color(0x1FFF3B30),
												shape = RoundedCornerShape(16.dp)
											)
											.clickable { println("Pressed!") }
											.padding(vertical = 3.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.clip(shape = RoundedCornerShape(16.dp))
												.width(24.dp)
												.height(24.dp)
										)
									}
									Text("Home",
										color = Color(0xFFFFFFFF),
										fontSize = 12.sp,
										fontWeight = FontWeight.Bold,
									)
								}
								Column(
									horizontalAlignment = Alignment.CenterHorizontally,
									modifier = Modifier
										.width(80.dp)
								){
									Column(
										horizontalAlignment = Alignment.CenterHorizontally,
										modifier = Modifier
											.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
											.clip(shape = RoundedCornerShape(16.dp))
											.fillMaxWidth()
											.padding(vertical = 3.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.clip(shape = RoundedCornerShape(16.dp))
												.width(24.dp)
												.height(24.dp)
										)
									}
									Text("ICE",
										color = Color(0xFF8E8E93),
										fontSize = 12.sp,
									)
								}
								Column(
									horizontalAlignment = Alignment.CenterHorizontally,
									modifier = Modifier
										.width(80.dp)
								){
									Column(
										horizontalAlignment = Alignment.CenterHorizontally,
										modifier = Modifier
											.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
											.clip(shape = RoundedCornerShape(16.dp))
											.fillMaxWidth()
											.padding(vertical = 3.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.clip(shape = RoundedCornerShape(16.dp))
												.width(24.dp)
												.height(24.dp)
										)
									}
									Text("Settings",
										color = Color(0xFF8E8E93),
										fontSize = 12.sp,
									)
								}
							}
						}
					}
					Column(
						modifier = Modifier
							.offset(x = 30.dp, y = -254.dp)
							.align(Alignment.BottomEnd)
							.padding(start = 30.dp)
					){
						CoilImage(
							imageModel = {"https://i.imgur.com/1tMFzp8.png"},
							imageOptions = ImageOptions(contentScale = ContentScale.Crop),
							modifier = Modifier
								.padding(bottom = 6.dp,start = 8.dp,end = 8.dp,)
								.clip(shape = RoundedCornerShape(28.dp))
								.width(56.dp)
								.height(56.dp)
						)
						Text("Emma Stone",
							color = Color(0xFFFFFFFF),
							fontSize = 12.sp,
							modifier = Modifier
								.padding(bottom = 6.dp,start = 1.dp,)
						)
						Text("Sister",
							color = Color(0xFF8E8E93),
							fontSize = 10.sp,
							modifier = Modifier
								.padding(start = 23.dp,)
						)
					}
				}
				Column(
					modifier = Modifier
						.padding(end = 32.dp,)
						.clip(shape = RoundedCornerShape(32.dp))
						.weight(1f)
						.background(
							color = Color(0xFF0C0C0E),
							shape = RoundedCornerShape(32.dp)
						)
				){
					Column(
						modifier = Modifier
							.padding(bottom = 89.dp,)
							.fillMaxWidth()
					){
						Row(
							horizontalArrangement = Arrangement.SpaceBetween,
							verticalAlignment = Alignment.CenterVertically,
							modifier = Modifier
								.fillMaxWidth()
								.padding(vertical = 15.dp,horizontal = 24.dp,)
						){
							Row(
								verticalAlignment = Alignment.CenterVertically,
							){
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.padding(end = 8.dp,)
										.width(18.dp)
										.height(18.dp)
								)
								Text("Whispr",
									color = Color(0xFFFFFFFF),
									fontSize = 18.sp,
									fontWeight = FontWeight.Bold,
								)
							}
							Row(
								verticalAlignment = Alignment.CenterVertically,
							){
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.padding(end = 8.dp,)
										.width(16.dp)
										.height(16.dp)
								)
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.padding(end = 8.dp,)
										.width(16.dp)
										.height(16.dp)
								)
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.width(24.dp)
										.height(16.dp)
								)
							}
						}
						Column(
							modifier = Modifier
								.fillMaxWidth()
								.padding(vertical = 20.dp,horizontal = 24.dp,)
						){
							Column(
								modifier = Modifier
									.padding(bottom = 20.dp,)
									.fillMaxWidth()
							){
								Text("ICE Contacts",
									color = Color(0xFFFFFFFF),
									fontSize = 24.sp,
									fontWeight = FontWeight.Bold,
									modifier = Modifier
										.padding(bottom = 4.dp,)
								)
								Text("These trusted contacts will be notified in an emergency.",
									color = Color(0xFF8E8E93),
									fontSize = 13.sp,
								)
							}
							Column(
								modifier = Modifier
									.fillMaxWidth()
							){
								Row(
									verticalAlignment = Alignment.CenterVertically,
									modifier = Modifier
										.padding(bottom = 12.dp,)
										.border(
											width = 1.dp,
											color = Color(0xFF222226),
											shape = RoundedCornerShape(16.dp)
										)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.background(
											color = Color(0xFF16161A),
											shape = RoundedCornerShape(16.dp)
										)
										.padding(16.dp)
								){
									Column(
										horizontalAlignment = Alignment.CenterHorizontally,
										modifier = Modifier
											.padding(end = 12.dp,)
											.padding(horizontal = 3.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.padding(bottom = 6.dp,)
												.clip(shape = RoundedCornerShape(28.dp))
												.width(56.dp)
												.height(56.dp)
										)
										Text("Sarah Miller",
											color = Color(0xFFFFFFFF),
											fontSize = 12.sp,
										)
									}
									Column(
										modifier = Modifier
											.padding(end = 12.dp,)
											.width(150.dp)
									){
										Row(
											verticalAlignment = Alignment.CenterVertically,
											modifier = Modifier
												.padding(bottom = 2.dp,)
												.fillMaxWidth()
										){
											Text("Sarah Miller",
												color = Color(0xFFFFFFFF),
												fontSize = 16.sp,
												fontWeight = FontWeight.Bold,
												modifier = Modifier
													.padding(end = 10.dp,)
											)
											Column(
												modifier = Modifier
													.clip(shape = RoundedCornerShape(6.dp))
													.background(
														color = Color(0x1FFF3B30),
														shape = RoundedCornerShape(6.dp)
													)
													.padding(vertical = 1.dp,horizontal = 8.dp,)
											){
												Text("Mom",
													color = Color(0xFFFF3B30),
													fontSize = 10.sp,
													fontWeight = FontWeight.Bold,
												)
											}
										}
										Text("+1 (555) 382-9901",
											color = Color(0xFF8E8E93),
											fontSize = 13.sp,
										)
									}
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(16.dp))
											.width(76.dp)
											.height(36.dp)
									)
								}
								Box(
									modifier = Modifier
										.padding(bottom = 12.dp,)
								){
									Row(
										verticalAlignment = Alignment.CenterVertically,
										modifier = Modifier
											.border(
												width = 1.dp,
												color = Color(0xFF222226),
												shape = RoundedCornerShape(16.dp)
											)
											.clip(shape = RoundedCornerShape(16.dp))
											.fillMaxWidth()
											.background(
												color = Color(0xFF16161A),
												shape = RoundedCornerShape(16.dp)
											)
											.padding(16.dp)
									){
										Column(
											horizontalAlignment = Alignment.CenterHorizontally,
											modifier = Modifier
												.padding(end = 12.dp,)
												.padding(horizontal = 3.dp,)
										){
											CoilImage(
												imageModel = {"https://i.imgur.com/1tMFzp8.png"},
												imageOptions = ImageOptions(contentScale = ContentScale.Crop),
												modifier = Modifier
													.padding(bottom = 6.dp,)
													.clip(shape = RoundedCornerShape(28.dp))
													.width(56.dp)
													.height(56.dp)
											)
											Text("Marcus Chen",
												color = Color(0xFFFFFFFF),
												fontSize = 12.sp,
											)
										}
										Column(
											modifier = Modifier
												.padding(end = 12.dp,)
												.width(150.dp)
										){
											Column(
												modifier = Modifier
													.padding(bottom = 2.dp,)
													.fillMaxWidth()
											){
												Text("Marcus Chen",
													color = Color(0xFFFFFFFF),
													fontSize = 16.sp,
													fontWeight = FontWeight.Bold,
												)
											}
											Text("+1 (555) 912-3294",
												color = Color(0xFF8E8E93),
												fontSize = 13.sp,
											)
										}
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.clip(shape = RoundedCornerShape(16.dp))
												.width(76.dp)
												.height(36.dp)
										)
									}
									Column(
										modifier = Modifier
											.offset(x = -81.dp, y = 37.dp)
											.align(Alignment.TopEnd)
											.padding(bottom = 37.dp)
											.clip(shape = RoundedCornerShape(6.dp))
											.background(
												color = Color(0x1FFF3B30),
												shape = RoundedCornerShape(6.dp)
											)
											.padding(vertical = 1.dp,horizontal = 8.dp,)
									){
										Text("Partner",
											color = Color(0xFFFF3B30),
											fontSize = 10.sp,
											fontWeight = FontWeight.Bold,
										)
									}
								}
								Row(
									verticalAlignment = Alignment.CenterVertically,
									modifier = Modifier
										.padding(bottom = 12.dp,)
										.border(
											width = 1.dp,
											color = Color(0xFF222226),
											shape = RoundedCornerShape(16.dp)
										)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.background(
											color = Color(0xFF16161A),
											shape = RoundedCornerShape(16.dp)
										)
										.padding(16.dp)
								){
									Column(
										horizontalAlignment = Alignment.CenterHorizontally,
										modifier = Modifier
											.padding(end = 12.dp,)
											.padding(horizontal = 8.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.padding(bottom = 6.dp,)
												.clip(shape = RoundedCornerShape(28.dp))
												.width(56.dp)
												.height(56.dp)
										)
										Text("Dr. Evans",
											color = Color(0xFFFFFFFF),
											fontSize = 12.sp,
										)
									}
									Column(
										modifier = Modifier
											.padding(end = 12.dp,)
											.width(150.dp)
											.padding(end = 11.dp,)
									){
										Row(
											verticalAlignment = Alignment.CenterVertically,
											modifier = Modifier
												.padding(bottom = 2.dp,)
												.fillMaxWidth()
										){
											Text("Dr. Evans",
												color = Color(0xFFFFFFFF),
												fontSize = 16.sp,
												fontWeight = FontWeight.Bold,
												modifier = Modifier
													.padding(end = 11.dp,)
											)
											Column(
												modifier = Modifier
													.clip(shape = RoundedCornerShape(6.dp))
													.background(
														color = Color(0x1FFF3B30),
														shape = RoundedCornerShape(6.dp)
													)
													.padding(vertical = 1.dp,horizontal = 8.dp,)
											){
												Text("Doctor",
													color = Color(0xFFFF3B30),
													fontSize = 10.sp,
													fontWeight = FontWeight.Bold,
												)
											}
										}
										Text("+1 (555) 412-0043",
											color = Color(0xFF8E8E93),
											fontSize = 13.sp,
										)
									}
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(16.dp))
											.width(76.dp)
											.height(36.dp)
									)
								}
								Row(
									verticalAlignment = Alignment.CenterVertically,
									modifier = Modifier
										.border(
											width = 1.dp,
											color = Color(0xFF222226),
											shape = RoundedCornerShape(16.dp)
										)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.background(
											color = Color(0xFF16161A),
											shape = RoundedCornerShape(16.dp)
										)
										.padding(16.dp)
								){
									Column(
										horizontalAlignment = Alignment.CenterHorizontally,
										modifier = Modifier
											.padding(end = 12.dp,)
											.padding(horizontal = 1.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.padding(bottom = 6.dp,)
												.clip(shape = RoundedCornerShape(28.dp))
												.width(56.dp)
												.height(56.dp)
										)
										Text("Officer Reed",
											color = Color(0xFFFFFFFF),
											fontSize = 12.sp,
										)
									}
									Box(
										modifier = Modifier
											.padding(end = 12.dp,)
									){
										Column(
											modifier = Modifier
												.width(150.dp)
										){
											Column(
												modifier = Modifier
													.fillMaxWidth()
											){
												Column(
													modifier = Modifier
														.padding(bottom = 2.dp,)
														.fillMaxWidth()
												){
													Text("Officer Reed",
														color = Color(0xFFFFFFFF),
														fontSize = 16.sp,
														fontWeight = FontWeight.Bold,
													)
												}
												Text("+1 (555) 762-1180",
													color = Color(0xFF8E8E93),
													fontSize = 13.sp,
												)
											}
										}
										Column(
											modifier = Modifier
												.offset(x = 8.dp, y = 1.dp)
												.align(Alignment.TopEnd)
												.padding(start = 8.dp, bottom = 1.dp)
												.clip(shape = RoundedCornerShape(6.dp))
												.background(
													color = Color(0x1FFF3B30),
													shape = RoundedCornerShape(6.dp)
												)
												.padding(vertical = 1.dp,horizontal = 8.dp,)
										){
											Text("Police",
												color = Color(0xFFFF3B30),
												fontSize = 10.sp,
												fontWeight = FontWeight.Bold,
											)
										}
									}
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(16.dp))
											.width(76.dp)
											.height(36.dp)
									)
								}
							}
						}
					}
					Column(
						modifier = Modifier
							.fillMaxWidth()
					){
						Column(
							horizontalAlignment = Alignment.End,
							modifier = Modifier
								.padding(bottom = 16.dp,)
								.fillMaxWidth()
								.padding(end = 24.dp,)
						){
							Column(
								modifier = Modifier
									.clip(shape = RoundedCornerShape(28.dp))
									.background(
										color = Color(0xFFFF3B30),
										shape = RoundedCornerShape(28.dp)
									)
									.shadow(
										elevation = 16.dp,
										spotColor = Color(0xFFFF3B30),
									)
									.clickable { println("Pressed!") }
									.padding(16.dp)
							){
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.clip(shape = RoundedCornerShape(28.dp))
										.width(24.dp)
										.height(24.dp)
								)
							}
						}
						Row(
							horizontalArrangement = Arrangement.SpaceBetween,
							verticalAlignment = Alignment.CenterVertically,
							modifier = Modifier
								.fillMaxWidth()
								.background(
									color = Color(0xFF0C0C0E),
								)
								.drawBehind {
									val borderTopWidth = 1.dp.toPx()
									drawLine(
										color = Color(0xFF222226),
										start = Offset(0f, borderTopWidth / 2),
										end = Offset(size.width, borderTopWidth / 2),
										strokeWidth = borderTopWidth
									)              
									}
								.padding(vertical = 10.dp,horizontal = 16.dp,)
						){
							Column(
								horizontalAlignment = Alignment.CenterHorizontally,
								modifier = Modifier
									.width(80.dp)
							){
								Column(
									horizontalAlignment = Alignment.CenterHorizontally,
									modifier = Modifier
										.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.padding(vertical = 3.dp,)
								){
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(16.dp))
											.width(24.dp)
											.height(24.dp)
									)
								}
								Text("Home",
									color = Color(0xFF8E8E93),
									fontSize = 12.sp,
								)
							}
							Column(
								horizontalAlignment = Alignment.CenterHorizontally,
								modifier = Modifier
									.width(80.dp)
							){
								Column(
									horizontalAlignment = Alignment.CenterHorizontally,
									modifier = Modifier
										.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.background(
											color = Color(0x1FFF3B30),
											shape = RoundedCornerShape(16.dp)
										)
										.clickable { println("Pressed!") }
										.padding(vertical = 3.dp,)
								){
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(16.dp))
											.width(24.dp)
											.height(24.dp)
									)
								}
								Text("ICE",
									color = Color(0xFFFFFFFF),
									fontSize = 12.sp,
									fontWeight = FontWeight.Bold,
								)
							}
							Column(
								horizontalAlignment = Alignment.CenterHorizontally,
								modifier = Modifier
									.width(80.dp)
							){
								Column(
									horizontalAlignment = Alignment.CenterHorizontally,
									modifier = Modifier
										.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.padding(vertical = 3.dp,)
								){
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(16.dp))
											.width(24.dp)
											.height(24.dp)
									)
								}
								Text("Settings",
									color = Color(0xFF8E8E93),
									fontSize = 12.sp,
								)
							}
						}
					}
				}
				Column(
					modifier = Modifier
						.clip(shape = RoundedCornerShape(32.dp))
						.weight(1f)
						.background(
							color = Color(0xFF0C0C0E),
							shape = RoundedCornerShape(32.dp)
						)
				){
					Column(
						modifier = Modifier
							.padding(bottom = 222.dp,)
							.fillMaxWidth()
					){
						Row(
							horizontalArrangement = Arrangement.SpaceBetween,
							verticalAlignment = Alignment.CenterVertically,
							modifier = Modifier
								.fillMaxWidth()
								.padding(vertical = 15.dp,horizontal = 24.dp,)
						){
							Row(
								verticalAlignment = Alignment.CenterVertically,
							){
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.padding(end = 8.dp,)
										.width(18.dp)
										.height(18.dp)
								)
								Text("Whispr",
									color = Color(0xFFFFFFFF),
									fontSize = 18.sp,
									fontWeight = FontWeight.Bold,
								)
							}
							Row(
								verticalAlignment = Alignment.CenterVertically,
							){
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.padding(end = 8.dp,)
										.width(16.dp)
										.height(16.dp)
								)
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.padding(end = 8.dp,)
										.width(16.dp)
										.height(16.dp)
								)
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.width(24.dp)
										.height(16.dp)
								)
							}
						}
						Column(
							modifier = Modifier
								.fillMaxWidth()
								.padding(vertical = 20.dp,horizontal = 24.dp,)
						){
							Column(
								modifier = Modifier
									.padding(bottom = 24.dp,)
									.fillMaxWidth()
							){
								Text("Settings",
									color = Color(0xFFFFFFFF),
									fontSize = 24.sp,
									fontWeight = FontWeight.Bold,
									modifier = Modifier
										.padding(bottom = 4.dp,)
								)
								Text("Configure triggers, automated distress signals & system status.",
									color = Color(0xFF8E8E93),
									fontSize = 13.sp,
								)
							}
							Column(
								modifier = Modifier
									.padding(bottom = 24.dp,)
									.fillMaxWidth()
							){
								Row(
									verticalAlignment = Alignment.CenterVertically,
									modifier = Modifier
										.padding(bottom = 12.dp,)
										.border(
											width = 1.dp,
											color = Color(0xFF222226),
											shape = RoundedCornerShape(16.dp)
										)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.background(
											color = Color(0xFF16161A),
											shape = RoundedCornerShape(16.dp)
										)
										.padding(16.dp)
								){
									Column(
										modifier = Modifier
											.padding(end = 16.dp,)
											.clip(shape = RoundedCornerShape(20.dp))
											.background(
												color = Color(0x1FFF3B30),
												shape = RoundedCornerShape(20.dp)
											)
											.clickable { println("Pressed!") }
											.padding(vertical = 9.dp,horizontal = 10.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.clip(shape = RoundedCornerShape(20.dp))
												.width(20.dp)
												.height(20.dp)
										)
									}
									Column(
										modifier = Modifier
											.padding(end = 16.dp,)
											.weight(1f)
									){
										Text("Auto-SMS Distress",
											color = Color(0xFFFFFFFF),
											fontSize = 16.sp,
											fontWeight = FontWeight.Bold,
											modifier = Modifier
												.padding(bottom = 4.dp,)
										)
										Text("Instantly send coordinates to ICE contacts when SOS is active.",
											color = Color(0xFF8E8E93),
											fontSize = 12.sp,
										)
									}
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(13.dp))
											.width(48.dp)
											.height(26.dp)
									)
								}
								Row(
									verticalAlignment = Alignment.CenterVertically,
									modifier = Modifier
										.padding(bottom = 12.dp,)
										.border(
											width = 1.dp,
											color = Color(0xFF222226),
											shape = RoundedCornerShape(16.dp)
										)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.background(
											color = Color(0xFF16161A),
											shape = RoundedCornerShape(16.dp)
										)
										.padding(16.dp)
								){
									Column(
										modifier = Modifier
											.padding(end = 16.dp,)
											.clip(shape = RoundedCornerShape(20.dp))
											.background(
												color = Color(0x1FFF3B30),
												shape = RoundedCornerShape(20.dp)
											)
											.clickable { println("Pressed!") }
											.padding(vertical = 9.dp,horizontal = 10.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.clip(shape = RoundedCornerShape(20.dp))
												.width(20.dp)
												.height(20.dp)
										)
									}
									Column(
										modifier = Modifier
											.padding(end = 16.dp,)
											.weight(1f)
									){
										Text("Live Location Sharing",
											color = Color(0xFFFFFFFF),
											fontSize = 16.sp,
											fontWeight = FontWeight.Bold,
											modifier = Modifier
												.padding(bottom = 4.dp,)
										)
										Text("Continuously update your location for 60 minutes during emergency.",
											color = Color(0xFF8E8E93),
											fontSize = 12.sp,
										)
									}
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(13.dp))
											.width(48.dp)
											.height(26.dp)
									)
								}
								Row(
									verticalAlignment = Alignment.CenterVertically,
									modifier = Modifier
										.border(
											width = 1.dp,
											color = Color(0xFF222226),
											shape = RoundedCornerShape(16.dp)
										)
										.clip(shape = RoundedCornerShape(16.dp))
										.fillMaxWidth()
										.background(
											color = Color(0xFF16161A),
											shape = RoundedCornerShape(16.dp)
										)
										.padding(16.dp)
								){
									Column(
										modifier = Modifier
											.padding(end = 16.dp,)
											.clip(shape = RoundedCornerShape(20.dp))
											.background(
												color = Color(0x08FFFFFF),
												shape = RoundedCornerShape(20.dp)
											)
											.clickable { println("Pressed!") }
											.padding(vertical = 9.dp,horizontal = 10.dp,)
									){
										CoilImage(
											imageModel = {"https://i.imgur.com/1tMFzp8.png"},
											imageOptions = ImageOptions(contentScale = ContentScale.Crop),
											modifier = Modifier
												.clip(shape = RoundedCornerShape(20.dp))
												.width(20.dp)
												.height(20.dp)
										)
									}
									Column(
										modifier = Modifier
											.padding(end = 16.dp,)
											.weight(1f)
									){
										Text("Trigger Loud Alarm",
											color = Color(0xFFFFFFFF),
											fontSize = 16.sp,
											fontWeight = FontWeight.Bold,
											modifier = Modifier
												.padding(bottom = 4.dp,)
										)
										Text("Blast maximum decibel warning horn to deter threats immediately.",
											color = Color(0xFF8E8E93),
											fontSize = 12.sp,
										)
									}
									CoilImage(
										imageModel = {"https://i.imgur.com/1tMFzp8.png"},
										imageOptions = ImageOptions(contentScale = ContentScale.Crop),
										modifier = Modifier
											.clip(shape = RoundedCornerShape(13.dp))
											.width(48.dp)
											.height(26.dp)
									)
								}
							}
							Column(
								modifier = Modifier
									.border(
										width = 1.dp,
										color = Color(0xFF222226),
										shape = RoundedCornerShape(16.dp)
									)
									.clip(shape = RoundedCornerShape(16.dp))
									.fillMaxWidth()
									.background(
										color = Color(0xFF16161A),
										shape = RoundedCornerShape(16.dp)
									)
									.padding(top = 16.dp,bottom = 16.dp,end = 16.dp,)
							){
								Text("Emergency Siren Delay",
									color = Color(0xFFFFFFFF),
									fontSize = 14.sp,
									fontWeight = FontWeight.Bold,
									modifier = Modifier
										.padding(bottom = 12.dp,start = 16.dp,)
								)
								Row(
									horizontalArrangement = Arrangement.SpaceBetween,
									verticalAlignment = Alignment.CenterVertically,
									modifier = Modifier
										.padding(start = 16.dp,)
										.fillMaxWidth()
								){
									Text("Countdown before loud sound triggers",
										color = Color(0xFF8E8E93),
										fontSize = 12.sp,
									)
									Text("3 Seconds",
										color = Color(0xFFFF3B30),
										fontSize = 12.sp,
										fontWeight = FontWeight.Bold,
									)
								}
							}
						}
					}
					Row(
						horizontalArrangement = Arrangement.SpaceBetween,
						verticalAlignment = Alignment.CenterVertically,
						modifier = Modifier
							.fillMaxWidth()
							.background(
								color = Color(0xFF0C0C0E),
							)
							.drawBehind {
								val borderTopWidth = 1.dp.toPx()
								drawLine(
									color = Color(0xFF222226),
									start = Offset(0f, borderTopWidth / 2),
									end = Offset(size.width, borderTopWidth / 2),
									strokeWidth = borderTopWidth
								)              
								}
							.padding(vertical = 10.dp,horizontal = 16.dp,)
					){
						Column(
							horizontalAlignment = Alignment.CenterHorizontally,
							modifier = Modifier
								.width(80.dp)
						){
							Column(
								horizontalAlignment = Alignment.CenterHorizontally,
								modifier = Modifier
									.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
									.clip(shape = RoundedCornerShape(16.dp))
									.fillMaxWidth()
									.padding(vertical = 3.dp,)
							){
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.clip(shape = RoundedCornerShape(16.dp))
										.width(24.dp)
										.height(24.dp)
								)
							}
							Text("Home",
								color = Color(0xFF8E8E93),
								fontSize = 12.sp,
							)
						}
						Column(
							horizontalAlignment = Alignment.CenterHorizontally,
							modifier = Modifier
								.width(80.dp)
						){
							Column(
								horizontalAlignment = Alignment.CenterHorizontally,
								modifier = Modifier
									.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
									.clip(shape = RoundedCornerShape(16.dp))
									.fillMaxWidth()
									.padding(vertical = 3.dp,)
							){
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.clip(shape = RoundedCornerShape(16.dp))
										.width(24.dp)
										.height(24.dp)
								)
							}
							Text("ICE",
								color = Color(0xFF8E8E93),
								fontSize = 12.sp,
							)
						}
						Column(
							horizontalAlignment = Alignment.CenterHorizontally,
							modifier = Modifier
								.width(80.dp)
						){
							Column(
								horizontalAlignment = Alignment.CenterHorizontally,
								modifier = Modifier
									.padding(bottom = 4.dp,start = 12.dp,end = 12.dp,)
									.clip(shape = RoundedCornerShape(16.dp))
									.fillMaxWidth()
									.background(
										color = Color(0x1FFF3B30),
										shape = RoundedCornerShape(16.dp)
									)
									.clickable { println("Pressed!") }
									.padding(vertical = 3.dp,)
							){
								CoilImage(
									imageModel = {"https://i.imgur.com/1tMFzp8.png"},
									imageOptions = ImageOptions(contentScale = ContentScale.Crop),
									modifier = Modifier
										.clip(shape = RoundedCornerShape(16.dp))
										.width(24.dp)
										.height(24.dp)
								)
							}
							Text("Settings",
								color = Color(0xFFFFFFFF),
								fontSize = 12.sp,
								fontWeight = FontWeight.Bold,
							)
						}
					}
				}
			}
		}
	}
}